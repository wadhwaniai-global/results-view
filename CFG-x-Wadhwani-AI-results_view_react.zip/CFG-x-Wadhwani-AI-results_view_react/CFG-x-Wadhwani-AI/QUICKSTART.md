# Quick Start Guide

## Running the React Application

### Step 1: Navigate to the project directory
```bash
cd CFG-x-Wadhwani-AI
```

### Step 2: Install dependencies (if not already done)
```bash
npm install
```

### Step 3: Start the development server
```bash
npm run dev
```

The application will start at `http://localhost:3000` and should automatically open in your browser.

## What Changed?

Your HTML application has been converted to a modern React application with:

### ✅ Modern React Components
- Converted all HTML pages to React components
- Used React Hooks for state management
- Proper component lifecycle management

### ✅ Professional Routing
- React Router for seamless navigation
- No more page reloads
- Clean URL structure (`/` for dashboard, `/results/:studentId` for results)

### ✅ Modern Build System
- Vite for fast development and optimized production builds
- Hot Module Replacement (HMR) - changes appear instantly
- Optimized bundle sizes

### ✅ Better Code Organization
```
src/
├── components/     # Reusable UI components (modals)
├── pages/          # Page-level components (Dashboard, Results)
├── services/       # API and Supabase integration
└── styles/         # CSS styling
```

### ✅ Same Functionality, Better Performance
- All features from HTML version work exactly the same
- Faster rendering with React's virtual DOM
- Better user experience with client-side routing

## Development Commands

- `npm run dev` - Start development server with hot reload
- `npm run build` - Create production build
- `npm run preview` - Preview production build locally

## Building for Production

When ready to deploy:

```bash
npm run build
```

This creates an optimized production build in the `dist/` folder.

## Differences from HTML Version

### Before (HTML):
- Multiple HTML files (`teacher-view-supabase.html`, `results-view-supabase.html`)
- Script tags loading libraries from CDN
- Global window variables
- Page reloads on navigation

### After (React):
- Single Page Application (SPA)
- ES6 modules with proper imports
- Component-based architecture
- Smooth client-side navigation
- Modern development workflow with Vite

## Troubleshooting

### Port already in use
If port 3000 is busy, Vite will automatically use the next available port.

### Dependencies issues
```bash
rm -rf node_modules package-lock.json
npm install
```

### Chart.js errors
The Chart.js integration uses `react-chartjs-2` which requires both `chart.js` and `react-chartjs-2` to be installed (already included in package.json).

## Next Steps

1. **Customize Supabase credentials**: Edit `src/services/supabaseClient.js` if needed
2. **Modify styling**: Update `src/styles/App.css`
3. **Add features**: Create new components in `src/components/`
4. **Deploy**: Use Vercel, Netlify, or any static hosting service

Enjoy your modern React application! 🚀
