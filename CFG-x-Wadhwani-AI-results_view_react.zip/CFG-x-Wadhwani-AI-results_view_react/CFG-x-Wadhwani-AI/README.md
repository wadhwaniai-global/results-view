# Reading Assessment Dashboard - React

A modern React application for tracking and managing student reading assessments with real-time performance analytics.

## Features

- **Teacher Dashboard**: View all students and their performance at a glance
- **Performance Charts**: Interactive charts showing student progress over time
- **Student Results**: Detailed assessment results with word-by-word analysis
- **Assessment Management**: Create and track reading assessments
- **Error Analysis**: Visualize reading errors (hits, misses, extras)
- **CSV Export**: Export student data for external analysis

## Tech Stack

- **React 18** - UI framework
- **Vite** - Build tool and dev server
- **React Router** - Client-side routing
- **Chart.js** - Data visualization
- **Bootstrap 5** - UI components
- **Supabase** - Backend and database
- **React ChartJS 2** - React wrapper for Chart.js

## Getting Started

### Prerequisites

- Node.js 16+ and npm

### Installation

1. Clone the repository
```bash
git clone <repository-url>
cd CFG-x-Wadhwani-AI
```

2. Install dependencies
```bash
npm install
```

3. Configure Supabase
   - Update the Supabase credentials in `src/services/supabaseClient.js`
   - Make sure your Supabase database has the required tables set up

4. Start the development server
```bash
npm run dev
```

The app will open at `http://localhost:3000`

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## Project Structure

```
CFG-x-Wadhwani-AI/
├── src/
│   ├── components/          # Reusable React components
│   │   ├── AddStudentModal.jsx
│   │   └── AssessmentModal.jsx
│   ├── pages/              # Page components
│   │   ├── TeacherDashboard.jsx
│   │   └── ResultsView.jsx
│   ├── services/           # API and service modules
│   │   ├── supabaseClient.js
│   │   └── api.js
│   ├── styles/             # CSS files
│   │   └── App.css
│   ├── App.jsx             # Main app component
│   └── main.jsx            # Entry point
├── index.html              # HTML template
├── vite.config.js          # Vite configuration
└── package.json            # Dependencies and scripts
```

## Features in Detail

### Teacher Dashboard
- View all students in a sortable list
- See latest CWPM (Correct Words Per Minute) scores
- Interactive multi-student performance chart
- Add new students
- Export data to CSV

### Results View
- Individual student performance trends
- Word-by-word reading passage analysis
- Error distribution pie chart
- Playback controls for reviewing assessments
- Create new assessments

## Supabase Database Schema

Required tables:
- `students` - Student information
- `teachers` - Teacher information
- `assessments` - Reading assessment records
- `word_results` - Individual word results per assessment
- `student_performance` - View combining student and assessment data

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)

## License

This project is licensed under the MIT License.
