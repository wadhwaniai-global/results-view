import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import TeacherDashboard from './pages/TeacherDashboard';
import ResultsView from './pages/ResultsView';
import './styles/App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<TeacherDashboard />} />
        <Route path="/results/:studentId" element={<ResultsView />} />
      </Routes>
    </Router>
  );
}

export default App;
