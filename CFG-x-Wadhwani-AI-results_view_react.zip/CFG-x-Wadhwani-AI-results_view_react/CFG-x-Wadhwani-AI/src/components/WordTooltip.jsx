import React, { useState } from 'react';

const WordTooltip = ({ word, align, error, children, index }) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  const handleClick = (e) => {
    if (error !== 'right') {
      const rect = e.currentTarget.getBoundingClientRect();
      setTooltipPosition({
        x: rect.left + rect.width / 2,
        y: rect.top - 10
      });
      setShowTooltip(!showTooltip);
    }
  };

  const handleClose = () => {
    setShowTooltip(false);
  };

  return (
    <>
      <span onClick={handleClick}>
        {children}
      </span>

      {showTooltip && error !== 'right' && (
        <>
          <div
            className="word-tooltip-overlay"
            onClick={handleClose}
          />
          <div
            className="word-tooltip"
            style={{
              left: `${tooltipPosition.x}px`,
              top: `${tooltipPosition.y}px`
            }}
          >
            <div className="word-tooltip-close" onClick={handleClose}>×</div>
            <div className="word-tooltip-content">
              <div className="word-tooltip-label">Correct Word:</div>
              <div className="word-tooltip-value correct-word">{word}</div>
              {align && (
                <>
                  <div className="word-tooltip-label">Student Pronounced:</div>
                  <div className="word-tooltip-value align-word">{align}</div>
                </>
              )}
              {!align && error === 'missed' && (
                <>
                  <div className="word-tooltip-label">Student Pronounced:</div>
                  <div className="word-tooltip-value align-word">(skipped)</div>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default WordTooltip;
