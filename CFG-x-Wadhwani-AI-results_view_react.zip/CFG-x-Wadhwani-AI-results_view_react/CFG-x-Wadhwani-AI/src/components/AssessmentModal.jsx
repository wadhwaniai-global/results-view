import React, { useState, useEffect } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

const AssessmentModal = ({ show, onHide, onSubmit }) => {
  const [formData, setFormData] = useState({
    assessmentDate: '',
    passage: '',
    cwpmScore: ''
  });

  useEffect(() => {
    if (show) {
      const today = new Date().toISOString().split('T')[0];
      setFormData(prev => ({ ...prev, assessmentDate: today }));
    }
  }, [show]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData({
      assessmentDate: '',
      passage: '',
      cwpmScore: ''
    });
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton className="border-0">
        <Modal.Title className="text-dark">Take New Assessment</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit} id="assessmentForm">
          <Form.Group className="mb-3">
            <Form.Label className="text-dark">Assessment Date</Form.Label>
            <Form.Control
              type="date"
              name="assessmentDate"
              value={formData.assessmentDate}
              onChange={handleChange}
              required
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label className="text-dark">Reading Passage</Form.Label>
            <Form.Control
              as="textarea"
              rows={4}
              name="passage"
              value={formData.passage}
              onChange={handleChange}
              placeholder="Enter the reading passage here..."
              required
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label className="text-dark">CWPM Score</Form.Label>
            <Form.Control
              type="number"
              name="cwpmScore"
              value={formData.cwpmScore}
              onChange={handleChange}
              placeholder="Enter CWPM score"
              min="0"
              max="200"
              required
            />
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer className="border-0">
        <Button variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        <Button variant="primary" type="submit" form="assessmentForm">
          Submit Assessment
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default AssessmentModal;
