// Supabase API integration
import { supabase } from './supabaseClient';
import mockData from '../data/mockData.json';

// Toggle between mock data and Supabase (set to true to use mock data)
const USE_MOCK_DATA = true;

export const api = {
  // ==================== STUDENT ENDPOINTS ====================

  // Get all students with latest CWPM
  getStudents: async () => {
    if (USE_MOCK_DATA) {
      // Create student performance view from mock data
      const studentsWithCWPM = mockData.students.map(student => {
        const studentAssessments = mockData.assessments.filter(a => a.student_id === student.id);
        const latestCWPM = studentAssessments.length > 0
          ? Math.max(...studentAssessments.map(a => a.cwpm_score))
          : 0;

        return {
          id: student.id,
          name: student.name,
          email: student.email,
          grade: student.grade,
          course: student.course,
          teacher_id: student.teacher_id,
          latest_cwpm: latestCWPM
        };
      });
      return studentsWithCWPM;
    }

    try {
      const { data, error } = await supabase
        .from('student_performance')
        .select('*')
        .order('name');

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching students:', error);
      return [];
    }
  },

  // Add new student
  addStudent: async (studentData) => {
    try {
      // Use the first teacher ID for now (in production, use authenticated user)
      const { data: teachers } = await supabase
        .from('teachers')
        .select('id')
        .limit(1);

      if (!teachers || teachers.length === 0) {
        throw new Error('No teacher found');
      }

      const { data, error } = await supabase
        .from('students')
        .insert([{
          teacher_id: teachers[0].id,
          name: studentData.name,
          email: studentData.email,
          password: studentData.password,
          grade: studentData.grade,
          course: studentData.course
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error adding student:', error);
      throw error;
    }
  },

  // Get student with all assessments
  getStudent: async (studentId) => {
    if (USE_MOCK_DATA) {
      const student = mockData.students.find(s => s.id === studentId);
      if (!student) throw new Error('Student not found');

      const assessments = mockData.assessments
        .filter(a => a.student_id === studentId)
        .sort((a, b) => new Date(a.assessment_date) - new Date(b.assessment_date));

      return {
        student: student,
        assessments: assessments
      };
    }

    try {
      // Get student data
      const { data: student, error: studentError } = await supabase
        .from('students')
        .select('*')
        .eq('id', studentId)
        .single();

      if (studentError) throw studentError;

      // Get all assessments for this student
      const { data: assessments, error: assessmentsError } = await supabase
        .from('assessments')
        .select('*')
        .eq('student_id', studentId)
        .order('assessment_date');

      if (assessmentsError) throw assessmentsError;

      return {
        student: student,
        assessments: assessments || []
      };
    } catch (error) {
      console.error('Error fetching student:', error);
      throw error;
    }
  },

  // Get student performance history
  getPerformance: async (studentId) => {
    if (USE_MOCK_DATA) {
      const assessments = mockData.assessments
        .filter(a => a.student_id === studentId)
        .sort((a, b) => new Date(a.assessment_date) - new Date(b.assessment_date));

      return assessments.map(assessment => ({
        date: new Date(assessment.assessment_date).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric'
        }),
        cwpm_score: assessment.cwpm_score,
        total_hits: assessment.total_hits,
        total_misses: assessment.total_misses,
        total_extras: assessment.total_extras
      }));
    }

    try {
      const { data, error } = await supabase
        .from('assessments')
        .select('assessment_date, cwpm_score, total_hits, total_misses, total_extras')
        .eq('student_id', studentId)
        .order('assessment_date');

      if (error) throw error;

      // Format dates for display
      return (data || []).map(assessment => ({
        date: new Date(assessment.assessment_date).toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric'
        }),
        cwpm_score: assessment.cwpm_score,
        total_hits: assessment.total_hits,
        total_misses: assessment.total_misses,
        total_extras: assessment.total_extras
      }));
    } catch (error) {
      console.error('Error fetching performance:', error);
      return [];
    }
  },

  // ==================== ASSESSMENT ENDPOINTS ====================

  // Get specific assessment with word results
  getAssessment: async (assessmentId) => {
    if (USE_MOCK_DATA) {
      const assessment = mockData.assessments.find(a => a.id === assessmentId);
      if (!assessment) throw new Error('Assessment not found');

      const words = mockData.word_results
        .filter(w => w.assessment_id === assessmentId)
        .sort((a, b) => a.word_position - b.word_position);

      return {
        assessment: assessment,
        words: words
      };
    }

    try {
      // Get assessment data
      const { data: assessment, error: assessmentError } = await supabase
        .from('assessments')
        .select('*')
        .eq('id', assessmentId)
        .single();

      if (assessmentError) throw assessmentError;

      // Get word results
      const { data: words, error: wordsError } = await supabase
        .from('word_results')
        .select('*')
        .eq('assessment_id', assessmentId)
        .order('word_position');

      if (wordsError) throw wordsError;

      return {
        assessment: assessment,
        words: words || []
      };
    } catch (error) {
      console.error('Error fetching assessment:', error);
      throw error;
    }
  },

  // Create new assessment
  createAssessment: async (assessmentData) => {
    try {
      const { student_id, passage, cwpm_score, words, assessment_date } = assessmentData;

      // Calculate totals
      const total_words = passage.split(/\s+/).length;
      const total_hits = words ? words.filter(w => w.type === 'hit').length : Math.floor(total_words * 0.8);
      const total_misses = words ? words.filter(w => w.type === 'miss').length : Math.floor(total_words * 0.15);
      const total_extras = words ? words.filter(w => w.type === 'extra').length : Math.floor(total_words * 0.05);

      // Use provided date or current date
      const assessmentDate = assessment_date || new Date().toISOString().split('T')[0];

      // Insert assessment
      const { data: assessment, error: assessmentError } = await supabase
        .from('assessments')
        .insert([{
          student_id,
          passage,
          cwpm_score,
          total_words,
          total_hits,
          total_misses,
          total_extras,
          assessment_date: assessmentDate
        }])
        .select()
        .single();

      if (assessmentError) throw assessmentError;

      // Insert word results if provided
      if (words && words.length > 0) {
        const wordRecords = words.map((word, index) => ({
          assessment_id: assessment.id,
          word_text: word.text,
          word_type: word.type,
          word_position: index + 1,
          timestamp_seconds: word.timestamp || index * 0.5
        }));

        const { error: wordsError } = await supabase
          .from('word_results')
          .insert(wordRecords);

        if (wordsError) throw wordsError;
      } else {
        // Generate mock word results
        const passageWords = passage.split(/\s+/);
        const wordRecords = passageWords.map((text, index) => {
          const rand = Math.random();
          let type = 'hit';
          if (rand < 0.15) type = 'miss';
          else if (rand < 0.25) type = 'extra';

          return {
            assessment_id: assessment.id,
            word_text: text,
            word_type: type,
            word_position: index + 1,
            timestamp_seconds: index * 0.5
          };
        });

        const { error: wordsError } = await supabase
          .from('word_results')
          .insert(wordRecords);

        if (wordsError) throw wordsError;
      }

      return { id: assessment.id, message: 'Assessment created successfully' };
    } catch (error) {
      console.error('Error creating assessment:', error);
      throw error;
    }
  }
};

// ==================== UTILITY FUNCTIONS ====================

// Export students to CSV
export const exportAllStudentsToCSV = async () => {
  try {
    const students = await api.getStudents();

    let csv = 'Student Name,Email,Grade,Course,Latest CWPM\n';

    students.forEach(student => {
      csv += `${student.name},${student.email},${student.grade},${student.course},${student.latest_cwpm || 0}\n`;
    });

    downloadCSV(csv, 'all_students.csv');
  } catch (error) {
    console.error('Error exporting CSV:', error);
    alert('Failed to export CSV');
  }
};

// Helper to download CSV
const downloadCSV = (csvContent, filename) => {
  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  window.URL.revokeObjectURL(url);
};
