import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { api, exportAllStudentsToCSV } from '../services/api';
import AddStudentModal from '../components/AddStudentModal';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const TeacherDashboard = () => {
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const parseChartDate = (dateStr) => {
    if (dateStr === 'No Data') return new Date(0);
    const [month, day] = dateStr.split(' ');
    const monthMap = {
      'Jan': 0, 'Feb': 1, 'Mar': 2, 'Apr': 3, 'May': 4, 'Jun': 5,
      'Jul': 6, 'Aug': 7, 'Sep': 8, 'Oct': 9, 'Nov': 10, 'Dec': 11
    };
    const currentYear = new Date().getFullYear();
    return new Date(currentYear, monthMap[month], parseInt(day));
  };

  const loadDashboard = async () => {
    try {
      setLoading(true);
      const studentsData = await api.getStudents();
      setStudents(studentsData);

      // Load performance data for chart
      await initChart(studentsData);
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const initChart = async (studentsData) => {
    if (studentsData.length === 0) {
      setChartData(null);
      return;
    }

    const colors = [
      '#007AFF', '#34C759', '#FF9500', '#FF3B30', '#AF52DE',
      '#FF2D55', '#5856D6', '#32ADE6', '#FFD60A', '#BF5AF2'
    ];

    const allDatesSet = new Set();
    const studentPerformanceMap = new Map();

    // Load all students performance
    for (let i = 0; i < studentsData.length; i++) {
      const student = studentsData[i];
      try {
        const performance = await api.getPerformance(student.id);
        if (performance.length > 0) {
          studentPerformanceMap.set(student.id, performance);
          performance.forEach(p => allDatesSet.add(p.date));
        }
      } catch (error) {
        console.error(`Error loading performance for ${student.name}:`, error);
      }
    }

    let sortedDates = Array.from(allDatesSet).sort((a, b) => {
      return parseChartDate(a) - parseChartDate(b);
    });

    if (sortedDates.length === 0) {
      sortedDates = ['No Data'];
    }

    const datasets = [];
    for (let i = 0; i < studentsData.length; i++) {
      const student = studentsData[i];
      const performance = studentPerformanceMap.get(student.id);

      if (performance && performance.length > 0) {
        const performanceMap = {};
        performance.forEach(p => {
          performanceMap[p.date] = p.cwpm_score;
        });

        const alignedData = sortedDates.map(date => {
          if (date === 'No Data') return null;
          return performanceMap[date] !== undefined ? performanceMap[date] : null;
        });

        datasets.push({
          label: student.name,
          data: alignedData,
          borderColor: colors[i % colors.length],
          backgroundColor: colors[i % colors.length] + '20',
          tension: 0.4,
          fill: false,
          pointRadius: 4,
          pointHoverRadius: 6,
          spanGaps: true
        });
      }
    }

    setChartData({
      labels: sortedDates,
      datasets: datasets
    });
  };

  const handleAddStudent = async (formData) => {
    try {
      await api.addStudent(formData);
      setShowAddModal(false);
      await loadDashboard();
      alert('Student added successfully!');
    } catch (error) {
      console.error('Error adding student:', error);
      alert('Failed to add student. Please try again.');
    }
  };

  const viewStudentResults = (studentId) => {
    navigate(`/results/${studentId}`);
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: {
          color: '#1d1d1f',
          padding: 15,
          usePointStyle: true,
          generateLabels: function(chart) {
            const datasets = chart.data.datasets;
            return datasets.map((dataset, i) => {
              const isVisible = chart.isDatasetVisible(i);
              return {
                text: dataset.label,
                fillStyle: isVisible ? dataset.borderColor : '#c0c0c0',
                strokeStyle: isVisible ? dataset.borderColor : '#c0c0c0',
                lineWidth: 2,
                hidden: false,
                index: i,
                pointStyle: 'circle',
                fontColor: isVisible ? '#1d1d1f' : '#c0c0c0'
              };
            });
          }
        },
        onClick: function(e, legendItem, legend) {
          const index = legendItem.index;
          const ci = legend.chart;

          if (ci.isDatasetVisible(index)) {
            ci.hide(index);
          } else {
            ci.show(index);
          }
        }
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        filter: function(tooltipItem) {
          return !tooltipItem.dataset.hidden;
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(0, 0, 0, 0.05)' },
        ticks: { color: '#6c757d' },
        title: {
          display: true,
          text: 'CWPM Score',
          color: '#6c757d'
        }
      },
      x: {
        grid: { display: false },
        ticks: { color: '#6c757d' },
        title: {
          display: true,
          text: 'Assessment Date',
          color: '#6c757d'
        }
      }
    }
  };

  return (
    <div className="container-fluid py-4">
      {/* Header */}
      <div className="glass-card p-4 mb-4">
        <div className="row align-items-center">
          <div className="col-md-8">
            <h1 className="h2 fw-bold text-dark mb-2">Reading Assessment Dashboard</h1>
            <p className="text-secondary mb-0">Monitor student progress and manage assessments</p>
          </div>
          <div className="col-md-4 text-md-end">
            <button className="btn btn-glass me-2" onClick={() => setShowAddModal(true)}>
              <i className="fas fa-plus me-2"></i>Add Student
            </button>
            <button className="btn btn-success" onClick={exportAllStudentsToCSV}>
              <i className="fas fa-download me-2"></i>Export CSV
            </button>
          </div>
        </div>
      </div>

      <div className="row g-4">
        {/* Performance Chart */}
        <div className="col-lg-8">
          <div className="glass-card p-4 h-100">
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h2 className="h4 fw-bold text-dark mb-0">Performance Overview</h2>
              <small className="text-secondary">
                <i className="fas fa-info-circle me-1"></i>
                Click student names to show/hide
              </small>
            </div>
            <div className="chart-container" style={{ height: '400px' }}>
              {loading ? (
                <div className="text-center py-4">
                  <div className="spinner-border text-secondary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : chartData ? (
                <Line data={chartData} options={chartOptions} />
              ) : (
                <div className="text-center py-4 text-secondary">
                  No student data available
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Students List */}
        <div className="col-lg-4">
          <div className="glass-card p-4 h-100">
            <h2 className="h4 fw-bold text-dark mb-4">Students</h2>
            <div className="student-list" style={{ maxHeight: '500px', overflowY: 'auto' }}>
              {loading ? (
                <div className="text-center py-4">
                  <div className="spinner-border text-secondary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : students.length === 0 ? (
                <div className="text-center py-4 text-secondary">
                  <i className="fas fa-users fa-2x mb-3 opacity-50"></i>
                  <p>No students found. Add your first student!</p>
                </div>
              ) : (
                students.map(student => {
                  const latestScore = student.latest_cwpm || 0;
                  return (
                    <div
                      key={student.id}
                      className="student-card p-3 mb-3"
                      onClick={() => viewStudentResults(student.id)}
                    >
                      <div className="d-flex justify-content-between align-items-start">
                        <div>
                          <h6 className="text-dark mb-1">{student.name}</h6>
                          <small className="text-secondary">
                            Grade {student.grade} • {student.course}
                          </small>
                        </div>
                        <span className="cwpm-badge badge">{latestScore} CWPM</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      <AddStudentModal
        show={showAddModal}
        onHide={() => setShowAddModal(false)}
        onSubmit={handleAddStudent}
      />
    </div>
  );
};

export default TeacherDashboard;
