import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Line, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { api } from '../services/api';
import AssessmentModal from '../components/AssessmentModal';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const ResultsView = () => {
  const { studentId } = useParams();
  const navigate = useNavigate();
  const [assessmentData, setAssessmentData] = useState(null);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPlayingErrorsOnly, setIsPlayingErrorsOnly] = useState(false);
  const [showAssessmentModal, setShowAssessmentModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [studentInfo, setStudentInfo] = useState({ name: '', grade: '', cwpm: 0 });
  const [trendData, setTrendData] = useState(null);
  const [pieData, setPieData] = useState(null);

  useEffect(() => {
    if (studentId) {
      loadStudentResults();
    } else {
      alert('No student selected!');
      navigate('/');
    }
  }, [studentId, navigate]);

  useEffect(() => {
    let interval;
    if ((isPlaying || isPlayingErrorsOnly) && assessmentData) {
      const wordsToPlay = isPlayingErrorsOnly
        ? assessmentData.words.map((word, idx) => ({ ...word, originalIndex: idx })).filter(w => w.type !== 'hit' && w.type !== 'right')
        : assessmentData.words.map((word, idx) => ({ ...word, originalIndex: idx }));

      let playIndex = 0;

      interval = setInterval(() => {
        if (playIndex < wordsToPlay.length) {
          setCurrentWordIndex(wordsToPlay[playIndex].originalIndex);
          playIndex++;
        } else {
          setIsPlaying(false);
          setIsPlayingErrorsOnly(false);
          playIndex = 0;
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, isPlayingErrorsOnly, assessmentData]);

  const loadStudentResults = async () => {
    try {
      setLoading(true);
      const studentData = await api.getStudent(studentId);
      const performance = await api.getPerformance(studentId);

      setStudentInfo({
        name: studentData.student.name,
        grade: studentData.student.grade,
        cwpm: performance.length > 0 ? performance[performance.length - 1].cwpm_score : 0
      });

      if (performance.length > 0) {
        const dates = performance.map(p => p.date);
        const cwpmScores = performance.map(p => p.cwpm_score);

        // Set trend chart data
        setTrendData({
          labels: dates,
          datasets: [{
            label: 'CWPM Progress',
            data: cwpmScores,
            borderColor: '#007AFF',
            backgroundColor: '#007AFF20',
            tension: 0.4,
            fill: true,
            pointRadius: 5,
            pointHoverRadius: 7
          }]
        });

        if (studentData.assessments.length > 0) {
          const latestAssessmentId = studentData.assessments[studentData.assessments.length - 1].id;
          const assessmentDetails = await api.getAssessment(latestAssessmentId);

          const assessment = {
            studentId: studentData.student.id,
            studentName: studentData.student.name,
            grade: studentData.student.grade,
            passage: assessmentDetails.assessment.passage,
            words: assessmentDetails.words.map(w => ({
              text: w.word_text,
              align: w.word_align || '',
              type: w.word_type,
              timestamp: parseFloat(w.timestamp_seconds)
            })),
            errors: {
              hit: assessmentDetails.assessment.total_hits,
              miss: assessmentDetails.assessment.total_misses,
              extra: assessmentDetails.assessment.total_extras
            }
          };

          setAssessmentData(assessment);

          // Set pie chart data
          setPieData({
            labels: ['Correct', 'Incorrect', 'Extra'],
            datasets: [{
              data: [assessment.errors.hit, assessment.errors.miss, assessment.errors.extra],
              backgroundColor: ['#34C759', '#FF3B30', '#FFD60A']
            }]
          });
        }
      }
    } catch (error) {
      console.error('Error loading results:', error);
      alert('Failed to load student results. Check your Supabase configuration!');
    } finally {
      setLoading(false);
    }
  };

  const handleAssessmentSubmit = async (formData) => {
    try {
      const words = formData.passage.split(/\s+/).map((text, i) => {
        const rand = Math.random();
        let type = 'hit';
        if (rand < 0.15) type = 'miss';
        else if (rand < 0.25) type = 'extra';

        return { text, type, timestamp: i * 0.5 };
      });

      await api.createAssessment({
        student_id: studentId,
        passage: formData.passage,
        cwpm_score: parseInt(formData.cwpmScore),
        words,
        assessment_date: formData.assessmentDate
      });

      setShowAssessmentModal(false);
      alert('Assessment submitted successfully!');
      window.location.reload();
    } catch (error) {
      console.error('Error submitting assessment:', error);
      alert('Failed to submit assessment. Please try again.');
    }
  };

  const togglePlay = () => {
    setIsPlayingErrorsOnly(false);
    setIsPlaying(!isPlaying);
  };

  const togglePlayErrorsOnly = () => {
    setIsPlaying(false);
    setIsPlayingErrorsOnly(!isPlayingErrorsOnly);
  };

  const nextWord = () => {
    if (assessmentData && currentWordIndex < assessmentData.words.length - 1) {
      setCurrentWordIndex(currentWordIndex + 1);
    }
  };

  const previousWord = () => {
    if (assessmentData && currentWordIndex > 0) {
      setCurrentWordIndex(currentWordIndex - 1);
    }
  };

  const playWord = (index) => {
    setCurrentWordIndex(index);
  };

  const trendOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false } },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(0, 0, 0, 0.05)' },
        ticks: { color: '#6c757d' }
      },
      x: {
        grid: { color: 'rgba(0, 0, 0, 0.05)' },
        ticks: { color: '#6c757d' }
      }
    }
  };

  const pieOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom',
        labels: { color: '#1d1d1f', padding: 15 }
      }
    }
  };

  const errorWords = assessmentData?.words.filter(w => w.type !== 'hit' && w.type !== 'right') || [];

  return (
    <div className="container-fluid py-4">
      {/* Header */}
      <div className="glass-card p-4 mb-4">
        <div className="row align-items-center">
          <div className="col-md-6">
            <h1 className="h3 fw-bold text-dark mb-2">Reading Assessment Results</h1>
            <p className="text-secondary mb-0">
              {loading ? 'Loading student data...' : `${studentInfo.name} - Grade ${studentInfo.grade}`}
            </p>
          </div>
          <div className="col-md-3 text-center">
            <div className="cwpm-score">{studentInfo.cwpm}</div>
            <div className="text-secondary">CWPM Score</div>
          </div>
          <div className="col-md-3 text-md-end">
            <div className="d-flex gap-2 justify-content-md-end flex-wrap align-items-center">
              <button className="btn btn-glass" onClick={() => setShowAssessmentModal(true)}>
                <i className="fas fa-plus me-2"></i>Take Assessment
              </button>
              <button className="btn btn-secondary" onClick={() => navigate('/')}>
                <i className="fas fa-arrow-left me-2"></i>Back
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="row g-4 mb-4">
        <div className="col-lg-8">
          <div className="glass-card p-4">
            <h2 className="h4 fw-bold text-dark mb-4">Performance Trend</h2>
            <div className="chart-container" style={{ height: '300px' }}>
              {loading ? (
                <div className="text-center py-4">
                  <div className="spinner-border text-secondary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : trendData ? (
                <Line data={trendData} options={trendOptions} />
              ) : (
                <div className="text-center py-4 text-secondary">No data available</div>
              )}
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="glass-card p-4">
            <h2 className="h4 fw-bold text-dark mb-4">Error Distribution</h2>
            <div className="chart-container" style={{ height: '300px' }}>
              {loading ? (
                <div className="text-center py-4">
                  <div className="spinner-border text-secondary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : pieData ? (
                <Doughnut data={pieData} options={pieOptions} />
              ) : (
                <div className="text-center py-4 text-secondary">No data available</div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Reading Passage */}
      <div className="glass-card p-4 mb-4">
        <h2 className="h4 fw-bold text-dark mb-4">Reading Passage Analysis</h2>
        <div className="passage mb-4">
          {loading ? (
            <div className="text-center py-4">
              <div className="spinner-border text-secondary" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          ) : assessmentData ? (
            assessmentData.words.map((word, index) => (
              <React.Fragment key={index}>
                <span
                  className={`word ${word.type} ${index === currentWordIndex ? 'active' : ''}`}
                  onClick={() => playWord(index)}
                >
                  {word.text}
                </span>
                {' '}
              </React.Fragment>
            ))
          ) : (
            <div className="text-center py-4 text-secondary">No passage data available</div>
          )}
        </div>

        <div className="row align-items-center">
          <div className="col-md-6">
            <div className="d-flex gap-2 align-items-center flex-wrap">
              <button className="btn btn-glass" onClick={togglePlay}>
                {isPlaying ? '⏸' : '▶'}
              </button>
              <button className="btn btn-glass" onClick={previousWord}>Previous</button>
              <button className="btn btn-glass" onClick={nextWord}>Next</button>
              <button className="btn btn-glass" onClick={togglePlayErrorsOnly}>
                {isPlayingErrorsOnly ? '⏸ Errors' : '▶ Play Errors Only'}
              </button>
            </div>
          </div>
          <div className="col-md-6">
            <div className="d-flex gap-3 flex-wrap justify-content-md-end mt-3 mt-md-0">
              <div className="d-flex align-items-center gap-2">
                <div className="legend-color" style={{ background: 'rgba(52, 199, 89, 0.3)' }}></div>
                <small className="text-secondary">Correct</small>
              </div>
              <div className="d-flex align-items-center gap-2">
                <div className="legend-color" style={{ background: 'rgba(255, 59, 48, 0.3)' }}></div>
                <small className="text-secondary">Incorrect</small>
              </div>
              <div className="d-flex align-items-center gap-2">
                <div className="legend-color" style={{ background: 'rgba(255, 152, 0, 0.3)' }}></div>
                <small className="text-secondary">Missed</small>
              </div>
              <div className="d-flex align-items-center gap-2">
                <div className="legend-color" style={{ background: 'rgba(255, 214, 10, 0.3)' }}></div>
                <small className="text-secondary">Extra</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Error Table */}
      <div className="glass-card p-4">
        <h2 className="h4 fw-bold text-dark mb-4">Error Analysis</h2>
        <div className="table-responsive">
          <table className="table table-light-custom table-hover">
            <thead>
              <tr>
                <th>Word</th>
                <th className="text-center">Correct</th>
                <th className="text-center">Incorrect</th>
                <th className="text-center">Missed</th>
                <th className="text-center">Extra</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="5" className="text-center py-4">
                    <div className="spinner-border text-secondary" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </div>
                  </td>
                </tr>
              ) : errorWords.length === 0 ? (
                <tr>
                  <td colSpan="5" className="text-center py-4 text-secondary">
                    No errors found!
                  </td>
                </tr>
              ) : (
                errorWords.map((word, index) => (
                  <tr key={index}>
                    <td className="text-dark"><strong>{word.text}</strong></td>
                    <td className="text-center">{word.type === 'hit' || word.type === 'right' ? '✓' : ''}</td>
                    <td className="text-center">{word.type === 'miss' || word.type === 'incorrect' ? '✓' : ''}</td>
                    <td className="text-center">{word.type === 'missed' ? '✓' : ''}</td>
                    <td className="text-center">{word.type === 'extra' ? '✓' : ''}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AssessmentModal
        show={showAssessmentModal}
        onHide={() => setShowAssessmentModal(false)}
        onSubmit={handleAssessmentSubmit}
      />
    </div>
  );
};

export default ResultsView;
