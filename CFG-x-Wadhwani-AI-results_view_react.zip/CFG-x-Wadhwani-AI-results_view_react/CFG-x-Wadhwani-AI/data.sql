-- Supabase Database Schema for Reading Assessment
-- Run this in your Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Teachers table
CREATE TABLE teachers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Students table
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teacher_id UUID NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    grade VARCHAR(10) NOT NULL,
    course VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Assessments table
CREATE TABLE assessments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    passage TEXT NOT NULL,
    cwpm_score INT NOT NULL,
    total_words INT NOT NULL,
    total_hits INT DEFAULT 0,
    total_misses INT DEFAULT 0,
    total_extras INT DEFAULT 0,
    assessment_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Word results table (stores individual word performance)
CREATE TABLE word_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    assessment_id UUID NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
    word_text VARCHAR(100) NOT NULL,
    word_type VARCHAR(10) NOT NULL CHECK (word_type IN ('hit', 'miss', 'extra')),
    word_position INT NOT NULL,
    timestamp_seconds DECIMAL(5,2) DEFAULT 0
);

-- Create indexes for better performance
CREATE INDEX idx_students_teacher ON students(teacher_id);
CREATE INDEX idx_assessments_student ON assessments(student_id);
CREATE INDEX idx_assessments_date ON assessments(assessment_date);
CREATE INDEX idx_word_results_assessment ON word_results(assessment_id);

-- Insert sample teacher
INSERT INTO teachers (id, name, email, password) VALUES 
('550e8400-e29b-41d4-a716-446655440000', 'Ms. Anderson', 'anderson@school.com', 'password123');

-- Insert sample students
INSERT INTO students (id, teacher_id, name, email, password, grade, course) VALUES
('650e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', 'Emma Johnson', 'emma.j@school.com', 'student123', '3', 'Reading A'),
('650e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', 'Liam Smith', 'liam.s@school.com', 'student123', '3', 'Reading A'),
('650e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440000', 'Olivia Davis', 'olivia.d@school.com', 'student123', '4', 'Reading B');

-- Insert sample assessments for Emma
INSERT INTO assessments (id, student_id, passage, cwpm_score, total_words, total_hits, total_misses, total_extras, assessment_date) VALUES
('750e8400-e29b-41d4-a716-446655440001', '650e8400-e29b-41d4-a716-446655440001', 'The quick brown fox jumps over the lazy dog.', 45, 9, 7, 2, 0, '2024-11-01'),
('750e8400-e29b-41d4-a716-446655440002', '650e8400-e29b-41d4-a716-446655440001', 'She sells seashells by the seashore.', 52, 6, 5, 1, 0, '2024-11-02'),
('750e8400-e29b-41d4-a716-446655440003', '650e8400-e29b-41d4-a716-446655440001', 'Peter Piper picked a peck of pickled peppers.', 58, 8, 7, 1, 0, '2024-11-03'),
('750e8400-e29b-41d4-a716-446655440004', '650e8400-e29b-41d4-a716-446655440001', 'How much wood would a woodchuck chuck.', 65, 7, 6, 1, 0, '2024-11-04'),
('750e8400-e29b-41d4-a716-446655440005', '650e8400-e29b-41d4-a716-446655440001', 'The quick brown fox jumps over the lazy dog.', 70, 9, 7, 1, 1, '2024-11-05');

-- Insert sample assessments for Liam
INSERT INTO assessments (student_id, passage, cwpm_score, total_words, total_hits, total_misses, total_extras, assessment_date) VALUES
('650e8400-e29b-41d4-a716-446655440002', 'The cat in the hat came back.', 40, 7, 6, 1, 0, '2024-11-01'),
('650e8400-e29b-41d4-a716-446655440002', 'Green eggs and ham are so good.', 48, 6, 5, 1, 0, '2024-11-03'),
('650e8400-e29b-41d4-a716-446655440002', 'One fish two fish red fish blue fish.', 55, 8, 7, 1, 0, '2024-11-05'),
('650e8400-e29b-41d4-a716-446655440002', 'The sun did not shine it was too wet to play.', 65, 11, 9, 2, 0, '2024-11-07');

-- Insert sample assessments for Olivia
INSERT INTO assessments (student_id, passage, cwpm_score, total_words, total_hits, total_misses, total_extras, assessment_date) VALUES
('650e8400-e29b-41d4-a716-446655440003', 'Where the wild things are is a great book.', 50, 8, 7, 1, 0, '2024-11-02'),
('650e8400-e29b-41d4-a716-446655440003', 'The very hungry caterpillar ate lots of food.', 56, 8, 7, 1, 0, '2024-11-04'),
('650e8400-e29b-41d4-a716-446655440003', 'Goodnight moon is a classic bedtime story.', 58, 7, 6, 1, 0, '2024-11-06');

-- Insert sample word results for Emma's latest assessment
INSERT INTO word_results (assessment_id, word_text, word_type, word_position, timestamp_seconds) VALUES
('750e8400-e29b-41d4-a716-446655440005', 'The', 'hit', 1, 0.0),
('750e8400-e29b-41d4-a716-446655440005', 'quick', 'hit', 2, 0.5),
('750e8400-e29b-41d4-a716-446655440005', 'brown', 'miss', 3, 1.0),
('750e8400-e29b-41d4-a716-446655440005', 'fox', 'hit', 4, 1.5),
('750e8400-e29b-41d4-a716-446655440005', 'jumps', 'hit', 5, 2.0),
('750e8400-e29b-41d4-a716-446655440005', 'over', 'hit', 6, 2.5),
('750e8400-e29b-41d4-a716-446655440005', 'the', 'hit', 7, 3.0),
('750e8400-e29b-41d4-a716-446655440005', 'lazy', 'extra', 8, 3.5),
('750e8400-e29b-41d4-a716-446655440005', 'dog', 'hit', 9, 4.0);

-- Create view for student performance with latest CWPM
CREATE OR REPLACE VIEW student_performance AS
SELECT 
    s.id,
    s.name,
    s.email,
    s.grade,
    s.course,
    s.teacher_id,
    COALESCE(MAX(a.cwpm_score), 0) as latest_cwpm,
    s.created_at
FROM students s
LEFT JOIN assessments a ON s.id = a.student_id
GROUP BY s.id, s.name, s.email, s.grade, s.course, s.teacher_id, s.created_at;

-- Enable Row Level Security (RLS)
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE word_results ENABLE ROW LEVEL SECURITY;

-- Create policies (adjust based on your authentication needs)
-- For now, allowing all authenticated users to read/write
CREATE POLICY "Allow all operations for authenticated users" ON teachers
    FOR ALL USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON students
    FOR ALL USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON assessments
    FOR ALL USING (true);

CREATE POLICY "Allow all operations for authenticated users" ON word_results
    FOR ALL USING (true);