// api.js - Client-side API integration
const API_URL = 'http://localhost:3000/api';

const api = {
    // ==================== STUDENT ENDPOINTS ====================
    
    // Get all students
    getStudents: async () => {
        try {
            const response = await fetch(`${API_URL}/students`);
            if (!response.ok) throw new Error('Failed to fetch students');
            return await response.json();
        } catch (error) {
            console.error('Error fetching students:', error);
            return [];
        }
    },
    
    // Add new student
    addStudent: async (studentData) => {
        try {
            const response = await fetch(`${API_URL}/students`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(studentData)
            });
            if (!response.ok) throw new Error('Failed to add student');
            return await response.json();
        } catch (error) {
            console.error('Error adding student:', error);
            throw error;
        }
    },
    
    // Get student with all assessments
    getStudent: async (studentId) => {
        try {
            const response = await fetch(`${API_URL}/students/${studentId}`);
            if (!response.ok) throw new Error('Student not found');
            return await response.json();
        } catch (error) {
            console.error('Error fetching student:', error);
            throw error;
        }
    },
    
    // Get student performance history
    getPerformance: async (studentId) => {
        try {
            const response = await fetch(`${API_URL}/students/${studentId}/performance`);
            if (!response.ok) throw new Error('Failed to fetch performance');
            return await response.json();
        } catch (error) {
            console.error('Error fetching performance:', error);
            return [];
        }
    },
    
    // ==================== ASSESSMENT ENDPOINTS ====================
    
    // Get specific assessment with word results
    getAssessment: async (assessmentId) => {
        try {
            const response = await fetch(`${API_URL}/assessments/${assessmentId}`);
            if (!response.ok) throw new Error('Assessment not found');
            return await response.json();
        } catch (error) {
            console.error('Error fetching assessment:', error);
            throw error;
        }
    },
    
    // Create new assessment
    createAssessment: async (assessmentData) => {
        try {
            const response = await fetch(`${API_URL}/assessments`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(assessmentData)
            });
            if (!response.ok) throw new Error('Failed to create assessment');
            return await response.json();
        } catch (error) {
            console.error('Error creating assessment:', error);
            throw error;
        }
    }
};

// ==================== TEACHER DASHBOARD FUNCTIONS ====================

// Load all students for teacher dashboard
async function loadTeacherDashboard() {
    try {
        const students = await api.getStudents();
        
        // Update global students array
        window.students = students;
        
        // Render chart
        if (window.chart) {
            window.chart.destroy();
        }
        initChart();
        
        // Render student list
        renderStudentList();
        
    } catch (error) {
        console.error('Error loading dashboard:', error);
        alert('Failed to load dashboard data');
    }
}

// Add student from form
async function submitNewStudent(formData) {
    try {
        const result = await api.addStudent(formData);
        alert('Student added successfully!');
        
        // Reload dashboard
        await loadTeacherDashboard();
        
        return result;
    } catch (error) {
        console.error('Error adding student:', error);
        alert('Failed to add student');
        throw error;
    }
}

// ==================== STUDENT RESULTS FUNCTIONS ====================

// Load student results page
async function loadStudentResults(studentId) {
    try {
        // Get student data and assessments
        const studentData = await api.getStudent(studentId);
        const performance = await api.getPerformance(studentId);
        
        // Update page with student info
        document.getElementById('studentName').textContent = 
            `${studentData.student.name} - Grade ${studentData.student.grade}`;
        
        // Process performance data
        const dates = performance.map(p => p.date);
        const cwpmScores = performance.map(p => p.cwpm_score);
        
        // Update CWPM display
        const latestCWPM = cwpmScores[cwpmScores.length - 1] || 0;
        document.getElementById('cwpmScore').textContent = latestCWPM;
        
        // Get latest assessment details
        if (studentData.assessments.length > 0) {
            const latestAssessmentId = studentData.assessments[studentData.assessments.length - 1].id;
            const assessmentDetails = await api.getAssessment(latestAssessmentId);
            
            // Update global assessment data
            window.assessmentData = {
                studentId: studentData.student.id,
                studentName: studentData.student.name,
                grade: studentData.student.grade,
                cwpm: cwpmScores,
                dates: dates,
                passage: assessmentDetails.assessment.passage,
                words: assessmentDetails.words.map(w => ({
                    text: w.word_text,
                    type: w.word_type,
                    timestamp: parseFloat(w.timestamp_seconds)
                })),
                errors: {
                    hit: assessmentDetails.assessment.total_hits,
                    miss: assessmentDetails.assessment.total_misses,
                    extra: assessmentDetails.assessment.total_extras
                }
            };
            
            // Render charts and passage
            initTrendChart();
            initPieChart();
            renderPassage();
            renderErrorTable();
        }
        
    } catch (error) {
        console.error('Error loading student results:', error);
        alert('Failed to load student results');
    }
}

// Submit new assessment
async function submitNewAssessment(studentId, passage, cwpmScore) {
    try {
        // Parse passage into words
        const words = passage.split(/\s+/).map((text, i) => {
            // Simulate random errors for demo
            const rand = Math.random();
            let type = 'hit';
            if (rand < 0.15) type = 'miss';
            else if (rand < 0.25) type = 'extra';
            
            return {
                text: text,
                type: type,
                timestamp: i * 0.5
            };
        });
        
        // Create assessment
        const assessmentData = {
            student_id: studentId,
            passage: passage,
            cwpm_score: cwpmScore,
            words: words
        };
        
        const result = await api.createAssessment(assessmentData);
        alert('Assessment submitted successfully!');
        
        // Reload page
        window.location.reload();
        
        return result;
    } catch (error) {
        console.error('Error submitting assessment:', error);
        alert('Failed to submit assessment');
        throw error;
    }
}

// ==================== UTILITY FUNCTIONS ====================

// Export students to CSV
async function exportAllStudentsToCSV() {
    try {
        const students = await api.getStudents();
        
        let csv = 'Student Name,Email,Grade,Course,Latest CWPM\n';
        
        students.forEach(student => {
            csv += `${student.name},${student.email},${student.grade},${student.course},${student.latest_cwpm || 0}\n`;
        });
        
        downloadCSV(csv, 'all_students.csv');
    } catch (error) {
        console.error('Error exporting CSV:', error);
        alert('Failed to export CSV');
    }
}

// Helper to download CSV
function downloadCSV(csvContent, filename) {
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Get student ID from URL or localStorage
function getStudentIdFromParams() {
    const params = new URLSearchParams(window.location.search);
    const urlId = params.get('student_id');
    const storedId = localStorage.getItem('selectedStudent');
    return urlId || storedId;
}

// ==================== EXAMPLE USAGE ====================

/*
// In teacher_view.html, replace the form submit handler:
document.getElementById('addStudentForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('studentName').value,
        email: document.getElementById('studentEmail').value,
        password: document.getElementById('studentPassword').value,
        grade: document.getElementById('studentGrade').value,
        course: document.getElementById('studentCourse').value
    };
    
    await submitNewStudent(formData);
    closeAddStudentModal();
});

// In results_view.html, add to page load:
window.addEventListener('DOMContentLoaded', async () => {
    const studentId = getStudentIdFromParams();
    if (studentId) {
        await loadStudentResults(studentId);
    }
});

// Update the assessment form submit:
document.getElementById('assessmentForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const studentId = getStudentIdFromParams();
    const passage = document.getElementById('passageInput').value;
    const cwpm = parseInt(document.getElementById('cwpmInput').value);
    
    await submitNewAssessment(studentId, passage, cwpm);
    closeAssessmentModal();
});
*/